const { Client, GatewayIntentBits } = require('discord.js');
const axios = require('axios');
const express = require('express');
const app = express();

// Configurações do Discord OAuth2
const clientId = 'SEU_CLIENT_ID'; // ID do seu bot
const clientSecret = 'SEU_CLIENT_SECRET'; // Substitua pelo client secret correto
const redirectUri = 'http://localhost:3001/callback'; // Redirecionamento após autenticação
const botToken = 'SEU_BOT_TOKEN'; // Token do bot (substitua pelo correto)
const guildId = 'SEU_GUILD_ID'; // ID do servidor para adicionar o bot

// Inicializa o bot Discord
const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers]
});

app.get('/', (req, res) => {
    res.send('<html><body><h1>Autentique-se no Discord</h1><a href="/verify"><button>Verificar</button></a></body></html>');
});

// Rota para iniciar o processo de autorização
app.get('/verify', (req, res) => {
    const authUrl = `https://discord.com/oauth2/authorize?client_id=${clientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=identify+guilds.join`;
    res.redirect(authUrl);
});

// Callback após autenticação
app.get('/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) return res.status(400).send('Código de autorização ausente.');

    console.log(`Código de autorização recebido: ${code}`);

    try {
        // Trocar código por token de acesso
        const tokenResponse = await axios.post('https://discord.com/api/oauth2/token', new URLSearchParams({
            client_id: clientId,
            client_secret: clientSecret,
            code,
            grant_type: 'authorization_code',
            redirect_uri: redirectUri,
            scope: 'identify guilds.join'
        }), {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        const accessToken = tokenResponse.data.access_token;
        console.log(`Token de acesso obtido: ${accessToken}`);

        // Obter informações do usuário autenticado
        const userResponse = await axios.get('https://discord.com/api/users/@me', {
            headers: { Authorization: `Bearer ${accessToken}` }
        });

        const userId = userResponse.data.id;
        console.log('Usuário autorizado:', userResponse.data);

        // Adicionar usuário ao servidor automaticamente
        try {
            await axios.put(`https://discord.com/api/guilds/${guildId}/members/${userId}`, {
                access_token: accessToken
            }, {
                headers: { 
                    'Authorization': `Bot ${botToken}`,
                    'Content-Type': 'application/json'
                }
            });

            console.log(`Usuário ${userId} adicionado ao servidor com sucesso!`);
            res.send(`<h1>Você foi adicionado ao servidor!</h1><p>Se não entrou, clique <a href="https://discord.gg/seuconvite">aqui</a>.</p>`);

        } catch (error) {
            console.error('Erro ao adicionar usuário ao servidor:', error.response ? error.response.data : error);
            res.status(500).send(`<h1>Erro ao adicionar usuário ao servidor.</h1>
                <p>Detalhes do erro: ${JSON.stringify(error.response.data)}</p>`);
        }

    } catch (error) {
        console.error('Erro ao processar o OAuth2:', error.response ? error.response.data : error);
        res.status(500).send('Erro ao autorizar o usuário.');
    }
});

// Evento quando o bot fica online
client.once('ready', () => {
    console.log(`Bot está online como ${client.user.tag}`);
});

// Inicia o bot
client.login(botToken).catch(err => {
    console.error('Erro ao iniciar o bot:', err);
});

// Iniciar o servidor Express na porta 3001
app.listen(3001, () => {
    console.log('Servidor de autorização rodando em http://localhost:3001');
});
